class Grid:
    def __init__(self, density, conductivity, heat_capacity, length, width,temperature, lattice_temp):
        self.density = density
        self.conductivity = conductivity
        self.heat_capacity = heat_capacity
        self.length = length
        self.width = width
        self.temperature = temperature
        self.lattice_temp = lattice_temp

