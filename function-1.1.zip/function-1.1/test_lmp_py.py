from lammps import lammps
lmp = lammps()
lmp.file("")